/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classwork.question1.lecture.room;
import java.util.Scanner;

/**
 *
 * @author dudi
 */

public class ResidentManager {
    public static void main(String[] args) {
        LectureRoom room = new LectureRoom();
        Scanner scanner = new Scanner(System.in);
        char choice;

        do {
            System.out.println("\n--- Lecture Room Control ---");
            System.out.println("W: Add Students");
            System.out.println("X: Remove Students");
            System.out.println("Y: Turn On Light");
            System.out.println("Z: Turn Off Light");
            System.out.println("Q: Quit");
            System.out.print("Enter your choice: ");
            choice = scanner.next().charAt(0);

            switch (choice) {
                case 'W':
                case 'w':
                    System.out.print("Enter number of students to add: ");
                    int add = scanner.nextInt();
                    room.addStudents(add);
                    System.out.println(add + " students added.");
                    break;

                case 'X':
                case 'x':
                    System.out.print("Enter number of students to remove: ");
                    int remove = scanner.nextInt();
                    room.removeStudents(remove);
                    System.out.println(remove + " students removed.");
                    break;

                case 'Y':
                case 'y':
                    System.out.print("Enter light number to turn on (1-3): ");
                    int onLight = scanner.nextInt();
                    room.turnOnLight(onLight);
                    System.out.println("Light " + onLight + " turned on.");
                    break;

                case 'Z':
                case 'z':
                    System.out.print("Enter light number to turn off (1-3): ");
                    int offLight = scanner.nextInt();
                    room.turnOffLight(offLight);
                    System.out.println("Light " + offLight + " turned off.");
                    break;

                case 'Q':
                case 'q':
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

            // Display current status
            System.out.println("\nCurrent Students: " + room.getStudentCount());
            System.out.println("Lights Status: 1-" + (room.isLightOn(1) ? "On" : "Off") + ", 2-" + (room.isLightOn(2) ? "On" : "Off") + ", 3-" + (room.isLightOn(3) ? "On" : "Off"));
            
        } while (choice != 'Q' && choice != 'q');

        scanner.close();
    }
}
